$(document).ready(function () {
    const solver =  localStorage.getItem("solver") 
    if(solver === "true"){
        $(".s_status").addClass("animate-bounce")
        $(".s_status").html("Auto Solver Started")
    }
    $(".width").change(function(){
        if($(this).val().trim() === "fw"){
            $("body").addClass("w-full")
            $("body").removeClass("w-my-w")
        }
        else if($(this).val().trim() === "dw"){
            $("body").addClass("w-my-w")
            $("body").removeClass("w-full")
        }
        else{
            $("body").addClass("w-my-w")
            $("body").removeClass("w-full")
        }
    })
    $(".theme").change(function() {
        if($(this).val().trim() === "dark"){
            $("html").addClass("dark")
        }
        else{
            $("html").removeClass("dark")
        }
    })
    $(".start").click(() => {
        localStorage.setItem("solver", "true") 
        chrome.tabs.executeScript(null, {
            "file": "solver.js"
        })
        $(".s_status").addClass("animate-bounce")
        $(".s_status").html("Auto Solver Started")
    })
    $(".stop").click(() => {
        localStorage.removeItem("solver")
        chrome.tabs.executeScript(null, {
            "file": "stop.js"
        })
        $(".s_status").removeClass("animate-bounce")
        $(".s_status").html("Auto Solver Started")
    })
})