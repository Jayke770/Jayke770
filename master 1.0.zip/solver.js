localStorage.setItem("solver", "true") 
var solver = setInterval(function() {
    console.log(solver)
    var solver = localStorage.getItem("solver")
    var points = document.querySelector("#points").innerText.split(".")
    var pts = parseInt(points[0])
    if(pts === 1000){
        clearInterval(solver)
    }
    if(solver === "false"){
        console.log(solver)
        clearInterval(solver)
    }
    var game = document.querySelector('#game').style.display
    if (game === "block" && game !== undefined) {
        var n1 = parseInt(document.querySelector('#num1').innerText) //number 1
        var n2 = parseInt(document.querySelector('#num2').innerText) //number 2
        var opr_arr = document.querySelector(".problem").innerText.split(" ")
        var opr = opr_arr[1].toString()
        if(opr == "*"){
            document.querySelector('#answer').value = (n1 * n2) // set answer value
            document.querySelector('#solve').click() // click solve
            setTimeout(() => { 
                if (game === "block") {
                   document.querySelector('.swal2-confirm').click()
                }
            }, 50) //click the sweet alert confirm button
        }
        if(opr === "-"){
            document.querySelector('#answer').value = (n1 - n2) // set answer value
            document.querySelector('#solve').click() // click solve
            setTimeout(() => { 
                if (game === "block") {
                   document.querySelector('.swal2-confirm').click()
                }
            }, 50) //click the sweet alert confirm button
        }
        if(opr === "+"){
            document.querySelector('#answer').value = (n1 + n2) // set answer value
            document.querySelector('#solve').click() // click solve
            setTimeout(() => { 
                if (game === "block") {
                   document.querySelector('.swal2-confirm').click()
                }
            }, 50) //click the sweet alert confirm button
        }
    }
}, 500);