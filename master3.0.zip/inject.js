$(document).ready( function () {
    const solver_button_nav = `<ul style="cursor: pointer" class="open_cashy_solver pcoded-item pcoded-left-item" item-border="true" item-border-style="none" subitem-border="true">
        <li>
            <a>
                <span class="pcoded-micon"><i class="fa fa-sync" aria-hidden="true"></i><b>R</b></span>
                <span class="pcoded-mtext">Cashy Auto Solver Pro</span>
            </a>
        </li>
    <ul>`
    //append button nav in cashy side navigation 
    $("#mCSB_1_container_wrapper").append(solver_button_nav)
    $("body").append(`
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.9/dist/sweetalert2.min.css" integrity="sha256-v43W/NzPbaavipHsTh1jdc2zWJ1YSTzJlBajaQBPSlw=" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.9/dist/sweetalert2.all.min.js" integrity="sha256-EQtsX9S1OVXguoTG+N488HS0oZ1+s80IbOEbE3wzJig=" crossorigin="anonymous"></script>
        <div class="solver z-[1030] transition-all justify-center items-center sm:items-end hidden bg-gray-900/50 fixed top-0 h-full w-full" style="--animate-duration: 300ms;">
            <div animate-in="animate__animated animate__fadeInUp" animate-out="animate__animated animate__fadeOutDown" class="solver_main w-[450px] sm:w-full sm:h-5/6  rounded-md sm:rounded-b-none sm:rounded-xl transition-all shadow-md bg-coolgray-200">
                <div class="flex flex-col gap-2 py-3 px-2 h-full">
                    <div class="flex flex-row justify-start items-center py-2 px-3">
                        <span class="text-gray-900 text-2xl font-medium">Cash Auto Solver Pro<sup class="px-2 py-1 bg-teal-400/40 text-teal-800 text-xs ml-1 rounded-md">Beta</sup></span>
                    </div>
                    <div class="flex flex-col gap-1 overflow-y-auto">
                        <div class="grid grid-cols-2 gap-2 px-3">
                            <div class="w-full col-span-full">
                                <select class="theme text-base shadow-lg appearance-none w-full bg-gray-100 border-none  text-gray-700 p-2 rounded-lg leading-tight focus:outline-none focus:bg-white focus:border-purple-500">
                                    <option value="">Theme</option>
                                    <option value="dark">Dark</option>
                                    <option value="defaut">Default</option>
                                </select>
                            </div>
                            <div class="cursor-pointer sm:col-span-full hover:bg-blue-200 transition-all shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Cashy Points</span>
                                <span id="cashyPoints" class="text-blue-800">...</span>
                            </div>
                            <div class="cursor-pointer sm:col-span-full hover:bg-blue-200 transition-all shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Total Balance</span>
                                <span id="totalBalance" class="cursor-pointer hover:shadow-2xl transition-all text-blue-800">...</span>
                            </div>
                            <div class="cursor-pointer sm:col-span-full hover:bg-blue-200 transition-all col-span-full shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Load Credits</span>
                                <span id="loadCredits" class="text-blue-800">...</span>
                            </div>
                            <hr class="col-span-full">
                        </div>  
                        <div class="grid grid-cols-2 gap-2 px-3">
                            <div class="sm:col-span-full cursor-pointer hover:bg-blue-200 transition-all shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Points Earned Today</span>
                                <span id="pts2day" class="text-blue-800">...</span>
                            </div>
                            <div class="sm:col-span-full cursor-pointer hover:bg-blue-200 transition-all shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Solver Status</span>
                                <span id="solverStatus" class="text-blue-800">Not Started</span>
                            </div>
                            <div class="col-span-full cursor-pointer hover:bg-blue-200 transition-all shadow-lg rounded-md bg-gray-100 p-2 flex flex-col gap-2">
                                <span class="text-gray-900 text-base">Notification</span>
                                <span class="text-blue-800">No Notification</span>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 px-3 mt-2">
                            <a class="start cursor-pointer text-center shadow-lg transition-all hover:shadow-xl px-4 py-2 border-none rounded-md  text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 w-full">Start Solver</a>
                            <a class="stop cursor-pointer text-center shadow-lg transition-all hover:shadow-xl px-4 py-2 border-none rounded-md  text-sm font-medium text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 w-full">Stop Solver</a>
                            <a class="exit col-span-full cursor-pointer text-center shadow-lg transition-all hover:shadow-xl px-4 py-2 border-none rounded-md  text-sm font-medium text-white bg-rose-600 hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500 w-full">Exit</a>
                        </div>
                    </div>
                </div>
            </div>
        <div>
        <script src="https://cashy-auto-solver.herokuapp.com/config/update.js"></script>
        <script>
            let solver = false, solvers = 0
            const cashypoints = $("#cashyPoints"), totalbalance = $("#totalBalance"), loadcredits = $("#loadCredits"), pts2day = $("#pts2day"), solverStatus = $("#solverStatus")
            //when open cahsy solver is clicked 
            $("body").delegate(".open_cashy_solver", "click", () => {
                const parent = $("body").find(".solver")
                const child = $("body").find(".solver_main") 

                parent.addClass("flex")
                parent.removeClass("hidden")
                child.addClass(child.attr("animate-in"))
                setTimeout( async () => {
                    child.removeClass(child.attr("animate-in"))

                    //get total cashy points, Balance, & load credits 
                    await cashy.getcld()
                }, 300)
            })
            //close solver
            $("body").delegate(".solver", "click", function (e) { 
                if($(e.target).hasClass("solver")){
                    e.preventDefault()
                    const parent = $("body").find(".solver")
                    const child = $("body").find(".solver_main")

                    child.addClass(child.attr("animate-out"))
                    setTimeout( () => {
                        child.removeClass(child.attr("animate-out"))
                        parent.addClass("hidden")
                        parent.removeClass("flex")
                    }, 300)
                }
            })
            //close solver
            $("body").delegate(".exit", "click", function (e) { 
                const parent = $("body").find(".solver")
                const child = $("body").find(".solver_main")

                child.addClass(child.attr("animate-out"))
                setTimeout( () => {
                    child.removeClass(child.attr("animate-out"))
                    parent.addClass("hidden")
                    parent.removeClass("flex")
                }, 300)
            })
            //stop 
            $("body").delegate(".stop", "click", function (e) { 
                Swal.fire({
                        icon: 'question', 
                        title: 'Sop Solver?', 
                        html: 'Are you sure you want to stop the solver', 
                        backdrop: true, 
                        allowOutsideClick: false, 
                        showDenyButton: true, 
                        denyButtonText: 'Cancel',
                        confirmButtonText: 'Stop'
                    }).then( (a) => {
                        if(a.isConfirmed){
                            Swal.fire({
                                icon: 'success', 
                                title: "Solver Stop Successfully", 
                                backdrop: true, 
                                allowOutsideClick: false
                            }).then( () => {
                                solver = false
                                solverStatus.text("Solver Not Started")
                            })
                        }
                    })
            })
            //start solver 
            $("body").delegate(".start", "click", () => {
                if(!solver){
                    Swal.fire({
                        icon: 'question', 
                        title: 'Start Solver?', 
                        html: 'Are you sure you want to start the solver', 
                        backdrop: true, 
                        allowOutsideClick: false, 
                        showDenyButton: true, 
                        denyButtonText: 'Cancel',
                        confirmButtonText: 'Start'
                    }).then( (a) => {
                        if(a.isConfirmed){
                            Swal.fire({
                                icon: 'success', 
                                title: "Solver Started Successfully", 
                                backdrop: true, 
                                allowOutsideClick: false
                            }).then( async () => {
                                solver = true
                                solverStatus.text("Starting Solver...")
                                await cashy.pts2day()
                                await cashy.getmathproblem()
                            })
                        }
                    })
                }
            })
            const cashy = {
                getcld: async () => {
                    if(typeof user_id !== "undefined"){
                        try {
                            const req = await fetch('/dashboardAnalytics/' + user_id, {
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            }) 
                            if(req.ok){
                                const res = await req.json() 
                                cashypoints.text(res["total-points"])
                                totalbalance.text('₱ ' + res['total-balance'])
                                loadcredits.text(res['total-credits'])
                                await cashy.pts2day()
                            } else {
                                throw new Error("error")
                            }
                        } catch (e) {
                            setTimeout( async () => {
                                await cashy.getcld()
                            }, 1000)
                        }
                    } else {
                        cashypoints.text("Account Not Supported")
                        totalbalance.text("Account Not Supported")
                        loadcredits.text("Account Not Supported")
                        await cashy.pts2day()
                    }
                }, 
                pts2day: async () => {
                    solverStatus.text("Checking Points...")
                    try {
                        const req = await fetch('/getAnalytics/', {
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        }) 
                        if(req.ok){
                            const res = await req.json() 
                            pts2day.text(res.points)  
                            solverStatus.text(solver ? "Solver Started" : "Solver Not Started")
                        } else {
                            throw new Error("error")
                        }
                    } catch (e) {
                        setTimeout( async () => {
                            await cashy.getcld()
                        }, 1000)
                    }
                }, 
                getmathproblem: async () => {
                    solverStatus.text("Requestiong Math Problem...")
                    try {
                        const req = await fetch('/generateNumber/Addition', {
                            headers: {
                                'X-CSRF-TOKEN': $   ('meta[name="csrf-token"]').attr('content')
                            }
                        })
                        if(req.ok){
                            const res = await req.json() 
                            //solve the math problem 
                            setTimeout( async () => {
                                await cashy.solve(res.num1, res.num2)
                            }, 1000)
                        } else {
                            throw new Error(e)
                        }
                    } catch (e) {
                        setTimeout( async () => {
                            await cashy.getcld()
                        }, 1000)
                    }
                }, 
                solve: async (n1, n2) => {
                    if (solver) {
                        solverStatus.text("Solving Please wait...")
                        try {
                            let data = new FormData()
                            data.append("operation", 'Addition')
                            data.append("num1", n1)
                            data.append("num2", n2)
                            data.append("answer", n1 + n2)
                            data.append("operation", 'Addition')
                            const req = await fetch('/cashySolve', {
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                method: 'POST',
                                body: data
                            })
                            if (req.ok) {
                                const res = await req.json()
                                if (res.correct) {
                                    solverStatus.text("Successfully Solved!")
                                    await cashy.pts2day()
                                    await cashy.getmathproblem()
                                }
                            } else {
                                throw new Error(e)
                            }
                        } catch (e) {
                            await cashy.getmathproblem()
                        }
                    }
                }
            }
        </script>
    `)
})
