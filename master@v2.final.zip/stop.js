$(".parent_solver").remove()
localStorage.setItem("solver","false")