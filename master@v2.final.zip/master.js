$(document).ready(() => {
    var solver = false
    var parent_solver_append = false
    //theme 
    var theme = localStorage.getItem("theme")
    if (theme === "dark") {
        $("html").addClass("dark")
    }
    $(".theme").change(function () {
        if ($(this).val() === "dark") {
            $("html").removeClass("default")
            $("html").addClass($(this).val())
            localStorage.setItem("theme", $(this).val())
        } else {
            $("html").removeClass("dark")
            $("html").addClass($(this).val())
            localStorage.setItem("theme", $(this).val())
        }
    })
    //start solver 
    $(".start").click( () => {
        if(!parent_solver_append){
            parent_solver_append = true
            $(".s_status").addClass("animate-bounce")
            $(".s_status").text("Auto Solver Started")
            chrome.tabs.executeScript(null, {
                file: "solver.js"
            })
        }
    })
    $(".stop").click( () => { 
        if(parent_solver_append){
            parent_solver_append = false
            $(".s_status").removeClass("animate-bounce")
            $(".s_status").text("Auto Solver Not Started")
            chrome.tabs.executeScript(null, {
                file: "stop.js"
            })
        }
    })
})