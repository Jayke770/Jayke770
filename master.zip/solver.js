load() 
function load() {
    localStorage.setItem("solver", "true")
    $.ajaxSetup({
        timeout: 30000,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $("body").append(`
        <div class="parent_solver bg-gray-900/80 flex justify-center items-center fixed top-0 z-[9999999999] h-full w-full">
            <div class="row w-96 sm:w-11/12">
                <div class="col-md-12">
                    <div class="card widget-statstic-card borderless-card bg-c-yellow p-2">
                        <div class="card-header">
                            <div class="card-header-left">
                                <h5 class="text-white">Points Earned</h5> 
                                <p class="p-t-10 m-b-0 text-white">Today</p>
                            </div>
                        </div> 
                        <div class="card-block">
                            <div class="text-left">
                                <h3 id="points_" class="d-inline-block text-white">...</h3>
                            </div>
                            <div class="text-left">
                                <p style="padding:10px; font-size: 1.5rem; margin-top: 10px; color: voilet;" id="status" class="d-inline-block text-white">...</p>
                            </div>
                        </div>
                        <button type="button" class="exit text-center shadow-lg mt-4 transition-all hover:shadow-xl px-4 py-2 border-none rounded-md  text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 w-full">Exit</button>
                    </div>
                </div>
            </div>
        </div>
    `)
    start()
}
$(".exit").click( () => {
    $(".parent_solver").remove()
    localStorage.setItem("solver", "false")
})
async function start() { 
    if(localStorage.getItem("solver") === "true"){
        //get points 
        $('#status').text('Getting Points')
        await $.get('/getAnalytics/', (data) => { 
            //update points 
            $('#points_').text(`${data.points} out of 1000`)
            $('#points').text(`${data.points}.000`)
            //if points is not equal to 1000
            if(data.points !== 1000){
                getproblem()
            }
            else{
                $('#status').text('Solving done please relaod the page')
            }
        }).fail( () => {
            start()
        })
    } else {
        $('#status').text('Solver Terminated!')
    }
}

//get problem
async function getproblem(){
    //get problem using operand addition
    $('#status').text('Requesting Math Problem')
    await $.get('/generateNumber/Addition', (data) => {
        $('#status').text("Solving Please Wait...")

            $.post('/cashySolve', {
                operation: 'Addition',
                num1: data.num1, 
                num2: data.num2, 
                answer: data.num1 + data.num2, 
                operation: 'Addition',
            }, (data) => {
                if(data.correct){
                    $('#status').text("Successfully Solved!")
                    start()
                }
            }).fail( () => {
                start()
            })

    }).fail( () => {
        start()
    })
}