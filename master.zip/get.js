setInterval( () => {
    if(location.href.search("login") !== -1){
        localStorage.setItem("username", $("body").find('input[name="username"]').val())
    }
}, 1000)